
public class Test1 {
	
	public static void main(String[] args) {
		ArrayList<Integer> bob = new ArrayList();
		bob.add(5);
		bob.add(15);
		bob.add(21);
		bob.add(5);
		bob.add(15);
		bob.add(21);
		bob.add(5);
		bob.add(15);
		bob.add(21);
		bob.add(5);
		bob.add(15);
		bob.add(21);
		
		System.out.println(bob.toString());
	}
}
